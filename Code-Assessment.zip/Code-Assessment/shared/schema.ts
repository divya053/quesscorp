import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  employeeId: text("employee_id").notNull().unique(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  department: text("department").notNull(),
});

export const attendances = pgTable("attendances", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").references(() => employees.id, { onDelete: 'cascade' }).notNull(),
  date: text("date").notNull(), // ISO date string YYYY-MM-DD
  status: text("status").notNull(), // 'Present' or 'Absent'
});

export const insertEmployeeSchema = createInsertSchema(employees).omit({ id: true });
export const insertAttendanceSchema = createInsertSchema(attendances).omit({ id: true });

// Custom validations
export const createEmployeeSchema = insertEmployeeSchema.extend({
  email: z.string().email("Invalid email format"),
  employeeId: z.string().min(1, "Employee ID is required"),
  fullName: z.string().min(1, "Full name is required"),
  department: z.string().min(1, "Department is required"),
});

export const createAttendanceSchema = insertAttendanceSchema.extend({
  status: z.enum(["Present", "Absent"]),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Invalid date format"),
  employeeId: z.coerce.number(),
});

export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = z.infer<typeof createEmployeeSchema>;

export type Attendance = typeof attendances.$inferSelect;
export type InsertAttendance = z.infer<typeof createAttendanceSchema>;
